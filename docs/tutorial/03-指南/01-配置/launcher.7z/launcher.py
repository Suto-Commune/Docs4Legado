from config import *
import os

command = f"{java_path} -jar {file_name} "
args = ""
for i in config.items():
    for j in config[i[0]].items():
        if not (j[1] == ""):
            args = args + f"--reader.{i[0]}.{j[0]}={j[1]} "

full_command = command + args
print(f"[INFO]执行命令中...\n\t命令为 '{full_command}'\n正在启动中...\n\n")
os.system(full_command)
