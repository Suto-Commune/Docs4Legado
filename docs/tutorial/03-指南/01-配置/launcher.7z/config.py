java_path = "java"  # 默认为java，可指定路径
file_name = "reader-pro-3.0.4.jar"  # reader服务端文件名
config = {
    "app": {
        "storagePath": "",  # 数据存储目录
        "showUI": False,  # 是否显示UI
        "debug": False,  # 是否调试模式
        "packaged": False,  # 是否打包为客户端
        "secure": False,  # 是否需要登录鉴权，开启后将支持多用户模式
        "inviteCode": "",  # 注册邀请码，为空时则开放注册，否则注册时需要输入邀请码
        "secureKey": "",  # 管理密码，开启鉴权时，前端管理用户空间的管理密码
        "proxy": False,  # 是否使用代理
        "proxyType": "HTTP",  # 代理类型
        "proxyHost": "",  # 代理 Host
        "proxyPort": "",  # 代理 port
        "proxyUsername": "",  # 代理鉴权 用户名
        "proxyPassword": "",  # 代理鉴权 密码
        "cacheChapterContent": False,  # 是否缓存章节内容
        "userLimit": 15,  # 用户上限，最大 15
        "userBookLimit": 200  # 用户书籍上限，默认最大 200
    },
    "server": {
        "port": 8080,  # 监听端口
        "webUrl": 'http://localhost:8080'  # web链接
    }
}
